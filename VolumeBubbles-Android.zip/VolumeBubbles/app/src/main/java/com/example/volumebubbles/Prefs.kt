package com.example.volumebubbles

import android.content.Context

class Prefs(c: Context) {
    private val sp = c.getSharedPreferences("vb", Context.MODE_PRIVATE)

    var size: Int            // dp
        get() = sp.getInt("size", 64)
        set(v) = sp.edit().putInt("size", v).apply()
    var opacity: Int         // 25..100
        get() = sp.getInt("opacity", 100)
        set(v) = sp.edit().putInt("opacity", v).apply()
    var mode: String         // both | plus | minus
        get() = sp.getString("mode", "both") ?: "both"
        set(v) = sp.edit().putString("mode", v).apply()
    var step: Int            // % per tap
        get() = sp.getInt("step", 10)
        set(v) = sp.edit().putInt("step", v).apply()

    fun pos(type: String): Pair<Int, Int>? =
        if (sp.contains("x_$type")) Pair(sp.getInt("x_$type", 0), sp.getInt("y_$type", 0)) else null

    fun setPos(type: String, x: Int, y: Int) =
        sp.edit().putInt("x_$type", x).putInt("y_$type", y).apply()

    fun clearPositions() =
        sp.edit().remove("x_plus").remove("y_plus").remove("x_minus").remove("y_minus").apply()
}
