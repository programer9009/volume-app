package com.example.volumebubbles

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.widget.Toast
import org.json.JSONObject

/** يعرض واجهة HTML (assets/index.html) ويربطها بخدمة الفقاعات الأصلية عبر VolumeBridge. */
class MainActivity : Activity() {

    private lateinit var web: WebView
    private lateinit var prefs: Prefs

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "VolumeBridge")
            loadUrl("file:///android_asset/index.html")
        }
        setContentView(web)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }

    private fun refreshService() {
        if (OverlayService.running) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_REFRESH))
        }
    }

    /** الدوال التالية تُستدعى من JavaScript على خيط خلفي، لذلك أي عمل على الواجهة يمر عبر runOnUiThread. */
    inner class Bridge {
        @JavascriptInterface
        fun start(): String {
            if (!Settings.canDrawOverlays(this@MainActivity)) {
                runOnUiThread {
                    Toast.makeText(this@MainActivity, "فعّل «الظهور فوق التطبيقات الأخرى» ثم ارجع", Toast.LENGTH_LONG).show()
                    startActivity(
                        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                    )
                }
                return "need_permission"
            }
            runOnUiThread { startForegroundService(Intent(this@MainActivity, OverlayService::class.java)) }
            return "ok"
        }

        @JavascriptInterface
        fun stop() {
            runOnUiThread {
                startService(Intent(this@MainActivity, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
            }
        }

        @JavascriptInterface
        fun isRunning(): Boolean = OverlayService.running

        @JavascriptInterface
        fun getVolume(): Int {
            val am = getSystemService(AUDIO_SERVICE) as AudioManager
            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
            return am.getStreamVolume(AudioManager.STREAM_MUSIC) * 100 / max
        }

        @JavascriptInterface
        fun applySettings(json: String) {
            val o = JSONObject(json)
            prefs.mode = o.optString("mode", prefs.mode)
            prefs.size = o.optInt("size", prefs.size).coerceIn(40, 110)
            prefs.opacity = o.optInt("opacity", prefs.opacity).coerceIn(25, 100)
            prefs.step = o.optInt("step", prefs.step).coerceIn(1, 50)
            runOnUiThread { refreshService() }
        }

        @JavascriptInterface
        fun resetPositions() {
            prefs.clearPositions()
            runOnUiThread { refreshService() }
        }
    }
}
