package com.example.volumebubbles

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.media.AudioManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.TextView
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.roundToInt

/** خدمة تعمل في المقدمة وترسم الفقاعتين فوق كل التطبيقات، حتى بعد إغلاق الواجهة. */
class OverlayService : Service() {

    companion object {
        const val ACTION_REFRESH = "com.example.volumebubbles.REFRESH"
        const val ACTION_STOP = "com.example.volumebubbles.STOP"
        private const val CHANNEL = "vb_channel"
        private const val NOTIF_ID = 1
        @Volatile var running = false
    }

    private lateinit var wm: WindowManager
    private lateinit var audio: AudioManager
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private val views = mutableListOf<View>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        audio = getSystemService(AUDIO_SERVICE) as AudioManager
        prefs = Prefs(this)
        running = true
        startAsForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        rebuild()
        return START_STICKY
    }

    override fun onDestroy() {
        removeAll()
        running = false
        super.onDestroy()
    }

    // ---------- الإشعار الإلزامي للخدمة ----------
    private fun startAsForeground() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "فقاعات الصوت", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        val open = PendingIntent.getActivity(
            this, 1, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .setContentTitle("فقاعات الصوت تعمل")
            .setContentText("اضغط لفتح الإعدادات")
            .setContentIntent(open)
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel),
                    "إيقاف", stop
                ).build()
            )
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    // ---------- بناء الفقاعات ----------
    private fun removeAll() {
        views.forEach { runCatching { wm.removeView(it) } }
        views.clear()
    }

    private fun rebuild() {
        removeAll()
        if (prefs.mode == "both" || prefs.mode == "plus") addBubble("plus")
        if (prefs.mode == "both" || prefs.mode == "minus") addBubble("minus")
    }

    private fun changeVolume(dir: Int) {
        val maxV = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
        val cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
        val delta = max(1, (maxV * prefs.step / 100f).roundToInt())
        val next = (cur + dir * delta).coerceIn(0, maxV)
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, next, AudioManager.FLAG_SHOW_UI)
    }

    private fun addBubble(type: String) {
        val dm = resources.displayMetrics
        val sizePx = (prefs.size * dm.density).roundToInt()
        val dir = if (type == "plus") 1 else -1
        val color = if (type == "plus") Color.parseColor("#2F5BFF") else Color.parseColor("#FF5A4E")

        val tv = TextView(this).apply {
            text = if (type == "plus") "+" else "−"
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            typeface = Typeface.DEFAULT_BOLD
            includeFontPadding = false
            setTextSize(TypedValue.COMPLEX_UNIT_PX, sizePx * 0.55f)
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color) }
            alpha = prefs.opacity / 100f
            elevation = 12f
        }

        val lp = WindowManager.LayoutParams(
            sizePx, sizePx,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            val saved = prefs.pos(type)
            x = saved?.first ?: (dm.widthPixels - sizePx - (20 * dm.density).toInt())
            y = saved?.second ?: (dm.heightPixels * 0.4f).toInt() +
                if (type == "minus") sizePx + (16 * dm.density).toInt() else 0
            x = x.coerceIn(0, max(0, dm.widthPixels - sizePx))
            y = y.coerceIn(0, max(0, dm.heightPixels - sizePx))
        }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var downX = 0f; var downY = 0f; var startX = 0; var startY = 0
        var dragging = false; var repeated = false

        val repeat = object : Runnable {
            override fun run() { changeVolume(dir); handler.postDelayed(this, 140) }
        }
        val hold = Runnable { repeated = true; changeVolume(dir); handler.postDelayed(repeat, 140) }

        tv.setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = e.rawX; downY = e.rawY; startX = lp.x; startY = lp.y
                    dragging = false; repeated = false
                    v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start()
                    handler.postDelayed(hold, 450)
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - downX; val dy = e.rawY - downY
                    if (!dragging && hypot(dx, dy) > slop) {
                        dragging = true
                        handler.removeCallbacks(hold); handler.removeCallbacks(repeat)
                    }
                    if (dragging) {
                        val m = resources.displayMetrics
                        lp.x = (startX + dx).toInt().coerceIn(0, max(0, m.widthPixels - sizePx))
                        lp.y = (startY + dy).toInt().coerceIn(0, max(0, m.heightPixels - sizePx))
                        wm.updateViewLayout(v, lp)
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    handler.removeCallbacks(hold); handler.removeCallbacks(repeat)
                    v.animate().scaleX(1f).scaleY(1f).setDuration(80).start()
                    if (dragging) prefs.setPos(type, lp.x, lp.y)
                    else if (e.actionMasked == MotionEvent.ACTION_UP && !repeated) changeVolume(dir)
                }
            }
            true
        }

        wm.addView(tv, lp)
        views.add(tv)
    }
}
