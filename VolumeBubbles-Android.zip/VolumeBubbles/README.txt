فقاعات الصوت - مشروع أندرويد (واجهة HTML + خدمة أصلية)

الواجهة: app/src/main/assets/index.html  (يمكنك تعديلها بحرية)
الفقاعات الحقيقية: OverlayService.kt  (نافذة عائمة تبقى بعد إغلاق التطبيق)
الربط: كائن VolumeBridge داخل MainActivity.kt

1) افتح المجلد في Android Studio ودعه يكمل Gradle Sync.
2) Run على الهاتف، أو Build > Build APK(s).
3) شغّل مفتاح "تفعيل الفقاعات"، وفعّل "الظهور فوق التطبيقات الأخرى" ثم ارجع وشغّله مرة ثانية.
